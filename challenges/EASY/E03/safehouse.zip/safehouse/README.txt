Ordinary receipts stored here. Check all files, even those hidden by Unix naming conventions.
